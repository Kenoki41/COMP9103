package sample;
public class Ticket {
    private boolean used;
    private int ticketID;
    private double price;
    private String day;
    private static int nextID = 100;    
    public Ticket(double price, String day){
        used = false;
        this.price = price;
        this.day = day;
        this.ticketID = nextID++;
    }  
    
    public Ticket(Ticket t){
        this.day = t.getDay();
        this.price = t.getPrice();
        this.ticketID = t.getTicketID();
        this.used = t.isUsed();
    }

 
    public void useThisTicket(){
        if(!used)
            used = true;
        else
            System.out.print("Ticket has been already used!");
    }

    public boolean isUsed() {
        return used;
    }

    public int getTicketID() {
        return ticketID;
    }

    public String getDay() {
        return day;
    }
    
    public int getId(){
        return this.ticketID;
    }    
    public double getPrice(){
        return this.price;
    }
       
}
