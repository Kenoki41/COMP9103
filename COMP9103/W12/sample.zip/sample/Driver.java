/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

/**
 *
 * @author aana3295
 */
public class Driver {
    public static void main(String [] args){
        TicketDB tdb = new TicketDB();
        tdb.processTextFile();
        tdb.reportTickets();
    }
}
