
package sample;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
public class TicketDB {
    private ArrayList<Ticket> ticketList;
    
    public TicketDB(){
        ticketList = new ArrayList<Ticket>();
    }
    
    public void add(Ticket t){
        if(t != null)
            ticketList.add(t);
    }
    
    public double averagePrice(){
        double total = 0;
        double avg = 0;        
        if(!ticketList.isEmpty()){
            for(Ticket t : ticketList)
                total += t.getPrice();
            avg = total / ticketList.size();
        }
        return avg;
    }
    
    public Ticket getTicketById(int id){
        for(Ticket t : ticketList)
            if(t.getId() == id)
                return t;
        return null;
    }
           
    public ArrayList<Ticket> getTicketsByPrice(double minPrice, double maxPrice){
        ArrayList<Ticket> copy = new ArrayList<Ticket>();
        for(Ticket t : ticketList)
            if(t.getPrice() > minPrice && t.getPrice() < maxPrice)
                copy.add(new Ticket(t));        
        return copy;
    }
    
    public void reportTickets(){
        try {
            PrintWriter pw = new PrintWriter(new File("tickets-report.txt"));
            pw.printf("%3s \t %-8s %-5s %4s\n","ID","Day", "Price","Used");
            for(Ticket t : ticketList)
                pw.printf("%3d \t%-8s %-5.2f  %4s\n",t.getId(),t.getDay(),t.getPrice(),t.isUsed());  
            pw.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TicketDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void processTextFile() {
        try {
            Scanner scan = new Scanner(new File("tickets.txt"));
            String day;
            double price;
            int numTickets = scan.nextInt();
            //scan.nextLine();
            for(int i=0;i<numTickets;i++){
                scan.nextLine();
                day = scan.nextLine();
                price = scan.nextDouble();
                
                ticketList.add(new Ticket(price,day));
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TicketDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
